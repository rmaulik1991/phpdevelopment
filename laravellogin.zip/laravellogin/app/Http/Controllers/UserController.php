<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Request;
use Redirect;
use Hash;
use Session;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{

    public function Login(Request $request)
    {
        // return 'dsf';
        $data = $request::all();
        $valid = Validator::make($data, [
            'email' => 'required|email|max:255',
            'password' => 'required|min:6',
        ]);

        if ($valid->fails())
        {
            // return 'fail';
            return redirect('loginform')
                        ->withErrors($valid)
                        ->withInput();
        }
        // return 'success';
        $result = User::where('email', $request::get('email'))->get();
        // return $result;
        if(count($result) != 0)
        {
            if(Hash::check($request::get('password'), $result[0]['Password']))
            {
                Session::flash('message', 'Login Successfull'); 
                return redirect::to('home');
                //->with('message', 'Login Successfull');
            }
            else
            {
                Session::flash('message', 'Invalid Email or Password!'); 
                return redirect::to('loginform');
                //->with('message', 'Invalid Email or Password!');
            }
        }
        else
        {
             Session::flash('message', 'Invalid Email or Password!'); 
            return redirect::to('loginform');
        }
    }

    public function registerUser(Request $request)
    {
        $data = $request::all();
        // return $data;
        // return $request::get('pno');
        $valid = Validator::make($data, [
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6',
            'pno' => 'required|numeric|unique:users',
            // 'type' => 'required',
            'status' => 'required',
        ]);

        if ($valid->fails())
        {
            // return 'fail';
            return redirect('adduser')
                        ->withErrors($valid)
                        ->withInput();
        }
        // return 'success';

        $user = new User;

        $user->Name = $request::get('name');
        $user->Email = $request::get('email');
        $user->PNo = $request::get('pno');
        $user->Password = Hash::make($request::get('password'));
        $user->Type = $request::get('type');
        $user->Status = $request::get('status');

        $user->save();
        // return $user;
        return redirect('home');
    }
    public function viewUser()
    {
        $result = User::get();
        return view('viewuser')->with('data', $result);
    }

    public function changeStatus(Request $request)
    {
        $id = $request::get('id');
        $status = $request::get('status');

        if($status == 1){
            $s = 0;
        }
        else{
            $s = 1;
        }
        $result = User::where('Id', $id)->update(['Status' => $s]);
        return $s;
        // return $request::all();
    }

    public function editUser($id)
    {
        $result = User::find($id);
        return view('edituser')->with('data', $result);
    }

    public function updateUser($id, Request $request)
    {
        $data = $request::all();
        $valid = Validator::make($data, [
            'name' => 'required|string|max:255',
            'pno' => 'required|numeric',
            'status' => 'required',
        ]);

        if ($valid->fails())
        {
            // return 'fail';
            return redirect('edituser')
                        ->withErrors($valid)
                        ->withInput();
        }
        // return 'success';

        $result = User::where('Id', $id)->update([
            'Name' => $request::get('name'),
            'PNo' => $request::get('pno'),
            'Status' => $request::get('status'),
            'Type' => $request::get('type'),
        ]);

        return redirect::to('home');
    }

    public function logout()
    {
        Auth::logout();
        return redirect::to('loginform');
    }
}
