@extends('layout')

@section('pageTitle')
View User

@stop

@section('pageContent')

<div class="row">
	<div class="col-md-9">
		@if(Session::has('message'))
			<p class="alert">{{ Session::get('message') }}</p>
		@endif
	</div>
	<div class="col-md-3 pull-right">
		@if( Auth::check() )
    		Current user: {{ Auth::user()->name }}
		@endif
		<a href="{{url('adduser')}}" class="btn">Add User</a>
		}
	</div>
	
	<div class="col-md-12">
		<table class="table">
			<thead>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Phone No.</th>
				<th>Type</th>
				<th>Status</th>
				<th>Edit</th>
			</thead>
			<tbody>
				@foreach($data as $row)
					<tr>
						<td>{{$row->Id}}</td>
						<td>{{$row->Name}}</td>
						<td>{{$row->Email}}</td>
						<td>{{$row->PNo}}</td>
						<td>{{$row->Type}}</td>
						<td><button type="button" id="status_{{$row->Id}}" style="" onclick="changeStatus(this.id)">{{$row->Status}}</button></td>
						<td><a href="{{url('edituser', $row->Id)}}">Edit</a></td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>

<script type="text/javascript">
function changeStatus(id) 
{
	var status = $('#'+id).text();
	var after = id.substr(id.indexOf("_") + 1);
	// alert(after);

	$.ajax({
		url: 'changestatus',
		type: 'POST',
		data: {'id':after, 'status': status, '_token':'{{ csrf_token() }}' },
		success: function(data){
			console.log(data);
			$('#'+id).text(data);
		}
	});
}
</script>
@stop