<?php $__env->startSection('pageTitle'); ?>
Edit User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>

<div class="row">
	<div class="col-md-4">
		<form method="post" action="<?php echo e(url('updateuser', $data->Id)); ?>">
		<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label>Name</label>
				<input type="text" name="name" id="name" value="<?php echo e($data->Name); ?>" class="form-control">
				<?php if($errors->has('name')): ?><p style="color:red;"><?php echo e($errors->first('name')); ?></p><?php endif; ?>
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="text" name="email" id="email" value="<?php echo e($data->Email); ?>"  class="form-control" readonly>
			</div>
			<div class="form-group">
				<label>Phone No.</label>
				<input type="text" name="pno" id="pno" value="<?php echo e($data->PNo); ?>"  class="form-control">
				<?php if($errors->has('pno')): ?><p style="color:red;"><?php echo e($errors->first('pno')); ?></p><?php endif; ?>
			</div>
			<div class="form-group">
				<label>Type</label>
				<select name="type" id="type" class="form-control">
					<!-- <option>Select Type</option> -->
					<?php if($data->Type == 'admin'): ?>
						<option value="admin" selected>Admin</option>
						<option value="superadmin">Super Admin</option>
					<?php elseif($data->Type == 'superadmin'): ?>
						<option value="admin">Admin</option>
						<option value="superadmin" selected>Super Admin</option>
					<?php else: ?>
					<option value="admin">Admin</option>
					<option value="superadmin">Super Admin</option>
					<?php endif; ?>
				</select> 
				<?php if($errors->has('type')): ?><p style="color:red;"><?php echo e($errors->first('type')); ?></p><?php endif; ?>
			</div>
			<div class="form-group">
				<label>Status</label>
				<?php if($data->Status == '1'): ?>
					<input type="radio" name="status" value="1" checked> Active
					<input type="radio" name="status" value="0"> Inactive
				<?php elseif($data->Status == '0'): ?>
					<input type="radio" name="status" value="1"> Active
					<input type="radio" name="status" value="0" checked> Inactive
				<?php else: ?>
					<input type="radio" name="status" value="1"> Active
					<input type="radio" name="status" value="0"> Inactive
				<?php endif; ?>
				<?php if($errors->has('status')): ?><p style="color:red;"><?php echo e($errors->first('status')); ?></p><?php endif; ?>
			</div>
			<div class="form-group">				
				<input type="submit" name="submit" value="Submit" class="btn">
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>