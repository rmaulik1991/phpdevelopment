<?php $__env->startSection('pageTitle'); ?>
Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageContent'); ?>

<div class="row">
	<div>
		<?php if(Session::has('message')): ?>
			<p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
		<?php endif; ?>
	</div>
	<div class="col-md-4">
		<form method="post" action="<?php echo e(url('login')); ?>">
		<?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label>Email</label>
				<input type="text" name="email" id="email" class="form-control">
				<?php if($errors->has('email')): ?><p style="color:red;"><?php echo e($errors->first('email')); ?></p><?php endif; ?>
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" id="password" class="form-control">
				<?php if($errors->has('password')): ?><p style="color:red;"><?php echo e($errors->first('password')); ?></p><?php endif; ?>
			</div>
			<div class="form-group">				
				<input type="submit" name="submit" value="Login" class="btn">
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>