@extends('layout')

@section('pageTitle')
Add User
@stop

@section('pageContent')

<div class="row">
	<div class="col-md-4">
		<form method="post" action="{{url('register')}}">
		{{ csrf_field() }}
			<div class="form-group">
				<label>Name</label>
				<input type="text" name="name" id="name" class="form-control">
				@if($errors->has('name'))<p style="color:red;">{{$errors->first('name')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="text" name="email" id="email" class="form-control">
				@if($errors->has('email'))<p style="color:red;">{{$errors->first('email')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Phone No.</label>
				<input type="text" name="pno" id="pno" class="form-control">
				@if($errors->has('pno'))<p style="color:red;">{{$errors->first('pno')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" id="password" class="form-control">
				@if($errors->has('password'))<p style="color:red;">{{$errors->first('password')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Type</label>
				<select name="type" id="type" class="form-control">
					<!-- <option>Select Type</option> -->
					<option value="admin">Admin</option>
					<option value="superadmin">Super Admin</option>
				</select> 
				@if($errors->has('type'))<p style="color:red;">{{$errors->first('type')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Status</label>
				<input type="radio" name="status" value="1"> Active
				<input type="radio" name="status" value="0"> Inactive
				@if($errors->has('status'))<p style="color:red;">{{$errors->first('status')}}</p>@endif
			</div>
			<div class="form-group">				
				<input type="submit" name="submit" value="Submit" class="btn">
			</div>
		</form>
	</div>
</div>

@stop