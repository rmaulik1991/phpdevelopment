@extends('layout')

@section('pageTitle')
Login
@stop

@section('pageContent')

<div class="row">
	<div>
		@if(Session::has('message'))
			<p class="alert alert-info">{{ Session::get('message') }}</p>
		@endif
	</div>
	<div class="col-md-4">
		<form method="post" action="{{url('login')}}">
		{{ csrf_field() }}
			<div class="form-group">
				<label>Email</label>
				<input type="text" name="email" id="email" class="form-control">
				@if($errors->has('email'))<p style="color:red;">{{$errors->first('email')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" id="password" class="form-control">
				@if($errors->has('password'))<p style="color:red;">{{$errors->first('password')}}</p>@endif
			</div>
			<div class="form-group">				
				<input type="submit" name="submit" value="Login" class="btn">
			</div>
		</form>
	</div>
</div>

@stop