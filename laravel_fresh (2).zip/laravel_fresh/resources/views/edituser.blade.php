@extends('layout')

@section('pageTitle')
Edit User
@stop

@section('pageContent')

<div class="row">
	<div class="col-md-4">
		<form method="post" action="{{url('updateuser', $data->Id)}}">
		{{ csrf_field() }}
			<div class="form-group">
				<label>Name</label>
				<input type="text" name="name" id="name" value="{{$data->Name}}" class="form-control">
				@if($errors->has('name'))<p style="color:red;">{{$errors->first('name')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="text" name="email" id="email" value="{{$data->Email}}"  class="form-control" readonly>
			</div>
			<div class="form-group">
				<label>Phone No.</label>
				<input type="text" name="pno" id="pno" value="{{$data->PNo}}"  class="form-control">
				@if($errors->has('pno'))<p style="color:red;">{{$errors->first('pno')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Type</label>
				<select name="type" id="type" class="form-control">
					<!-- <option>Select Type</option> -->
					@if($data->Type == 'admin')
						<option value="admin" selected>Admin</option>
						<option value="superadmin">Super Admin</option>
					@elseif($data->Type == 'superadmin')
						<option value="admin">Admin</option>
						<option value="superadmin" selected>Super Admin</option>
					@else
					<option value="admin">Admin</option>
					<option value="superadmin">Super Admin</option>
					@endif
				</select> 
				@if($errors->has('type'))<p style="color:red;">{{$errors->first('type')}}</p>@endif
			</div>
			<div class="form-group">
				<label>Status</label>
				@if($data->Status == '1')
					<input type="radio" name="status" value="1" checked> Active
					<input type="radio" name="status" value="0"> Inactive
				@elseif($data->Status == '0')
					<input type="radio" name="status" value="1"> Active
					<input type="radio" name="status" value="0" checked> Inactive
				@else
					<input type="radio" name="status" value="1"> Active
					<input type="radio" name="status" value="0"> Inactive
				@endif
				@if($errors->has('status'))<p style="color:red;">{{$errors->first('status')}}</p>@endif
			</div>
			<div class="form-group">				
				<input type="submit" name="submit" value="Submit" class="btn">
			</div>
		</form>
	</div>
</div>

@stop